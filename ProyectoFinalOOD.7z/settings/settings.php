<?php

    // Constante para el controlador principal
    define("PRINCIPAL_CONTROLLER", "Home");
    // Constante para la accion principal
    define("PRINCIPAL_ACTION", "index");

?>